Lab 3 Code to figure out motor logistics
